@extends('layouts.app')

@section('content')
<div class="d-flex justify-content-between mb-3">
    <h2>Experiences</h2>
    <a href="{{ route('experiences.create') }}" class="btn btn-primary">Add Experience</a>
</div>

@forelse($experiences as $experience)
    <div class="card mb-3">
        <div class="card-body">
            <h5>{{ $experience->city->name }} - {{ $experience->housing_type }}</h5>
            <p><strong>Budget:</strong> {{ $experience->monthly_budget }}</p>
            <p>{{ $experience->cultural_challenges }}</p>
            <p>{{ $experience->academic_environment }}</p>
            <p><strong>By:</strong> {{ $experience->user->name }}</p>

            <div class="d-flex flex-wrap gap-3 mb-3 text-muted small">
                <span><strong>{{ $experience->upvotes_count }}</strong> upvotes</span>
                <span><strong>{{ $experience->downvotes_count }}</strong> downvotes</span>
                <span><strong>{{ $experience->vote_score }}</strong> score</span>
            </div>

            <div class="d-flex flex-wrap gap-2">
                <form method="POST" action="{{ route('vote.store', ['type' => 'experience', 'id' => $experience->id]) }}">
                    @csrf
                    <input type="hidden" name="vote" value="1">
                    <button type="submit" class="btn btn-sm {{ $experience->userVote() === 1 ? 'btn-success' : 'btn-outline-success' }}">
                        ▲ Upvote
                    </button>
                </form>

                <form method="POST" action="{{ route('vote.store', ['type' => 'experience', 'id' => $experience->id]) }}">
                    @csrf
                    <input type="hidden" name="vote" value="-1">
                    <button type="submit" class="btn btn-sm {{ $experience->userVote() === -1 ? 'btn-danger' : 'btn-outline-danger' }}">
                        ▼ Downvote
                    </button>
                </form>

                <a href="{{ route('cities.show', $experience->city) }}" class="btn btn-outline-secondary btn-sm">View City</a>

                @if(auth()->id() === $experience->user_id)
                    <a href="{{ route('experiences.edit', $experience) }}" class="btn btn-warning btn-sm">Edit</a>

                    <form action="{{ route('experiences.destroy', $experience) }}" method="POST" class="d-inline">
                        @csrf
                        @method('DELETE')
                        <button class="btn btn-danger btn-sm">Delete</button>
                    </form>
                @endif
            </div>
        </div>
    </div>
@empty
    <div class="card">
        <div class="card-body">
            <p class="mb-0 text-muted">No experiences yet.</p>
        </div>
    </div>
@endforelse
@endsection
