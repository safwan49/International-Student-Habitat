# Student Platform Sprint 3

This package contains only the files needed for the Sprint 3 features shown in the requirement image.

## Sprint 3 features included

1. Users can post questions related to a specific country or city.
2. Users can upvote and downvote both:
   - experience reports
   - questions
3. Logged-in users can respond to posted questions.
   - No experienced-user tag/role is added.
4. Question owners can mark one response as Most Helpful.
5. Questions and answers can be sorted by:
   - Most Recent
   - Most Helpful

## How to use

Copy these files/folders into your Laravel project on the existing `sprint 3` branch and replace the matching files.

After copying, run:

```bash
php artisan optimize:clear
php artisan migrate
```

If the database already has these migrations, you do not need to run `migrate:fresh`.
