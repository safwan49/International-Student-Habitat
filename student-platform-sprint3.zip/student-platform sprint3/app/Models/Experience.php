<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Experience extends Model
{
    protected $fillable = [
        'user_id',
        'city_id',
        'housing_type',
        'monthly_budget',
        'cultural_challenges',
        'academic_environment',
        'part_time_job_experience',
    ];

    protected $appends = [
        'upvotes_count',
        'downvotes_count',
        'vote_score',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function city()
    {
        return $this->belongsTo(City::class);
    }

    public function votes()
    {
        return $this->morphMany(Vote::class, 'votable');
    }

    public function getUpvotesCountAttribute()
    {
        return $this->votes()->where('vote', 1)->count();
    }

    public function getDownvotesCountAttribute()
    {
        return $this->votes()->where('vote', -1)->count();
    }

    public function getVoteScoreAttribute()
    {
        return $this->votes()->sum('vote');
    }

    public function userVote()
    {
        if (!auth()->check()) {
            return null;
        }

        return $this->votes()->where('user_id', auth()->id())->value('vote');
    }
}
